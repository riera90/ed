# Contributing
please, contact @riera90 at telegram

All contributions are wellcome!


# TODO List
 - update readme to reflect dinamic linking
